// tests/serverApi.test.js
import test from 'node:test';
import assert from 'node:assert';
import { server } from '../src/server.js';
import { config } from '../src/config.js';
import { db } from '../src/db/database.js';

let baseUrl;
let testServer;

test.before(async () => {
  await new Promise((resolve) => {
    testServer = server.listen(0, () => {
      const port = testServer.address().port;
      baseUrl = `http://localhost:${port}`;
      resolve();
    });
  });
});

test.after(async () => {
  await new Promise((resolve) => testServer.close(resolve));
});

test('API - Registration and Domain Policy Enforcement', async () => {
  // 1. Invalid domain should fail
  const badDomainRes = await fetch(`${baseUrl}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: 'hacker@unauthorized-school.edu',
      password: 'password123',
      fullName: 'Hacker User'
    })
  });
  assert.strictEqual(badDomainRes.status, 400);
  const badData = await badDomainRes.json();
  assert.match(badData.error, /Hệ thống chỉ chấp nhận các tên miền/);

  // 2. Valid domain succeeds
  const cleanEmail = `test_student_${Date.now()}@gmail.com`;
  const registerRes = await fetch(`${baseUrl}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: cleanEmail,
      password: 'password123',
      fullName: 'Nguyễn Văn Test'
    })
  });
  assert.strictEqual(registerRes.status, 201);
  const regData = await registerRes.json();
  assert.ok(regData.token);
  assert.strictEqual(regData.user.role, 'student');
});

test('API - Initial Admin Provisioning via ADMIN_EMAIL', async () => {
  const adminEmail = config.adminEmail; // e.g. 'owner.admin@gmail.com'

  // Clean up if exists
  const existingAdmin = db.prepare('SELECT id FROM users WHERE email = ?').get(adminEmail);
  if (existingAdmin) {
    db.prepare('DELETE FROM admin_audit_logs WHERE admin_id = ?').run(existingAdmin.id);
    db.prepare('DELETE FROM workshop_teams WHERE created_by = ?').run(existingAdmin.id);
    db.prepare('DELETE FROM community_posts WHERE author_id = ?').run(existingAdmin.id);
    db.prepare('DELETE FROM users WHERE id = ?').run(existingAdmin.id);
  }

  const res = await fetch(`${baseUrl}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: adminEmail,
      password: 'adminPassword123',
      fullName: 'Owner Administrator'
    })
  });

  assert.strictEqual(res.status, 201);
  const data = await res.json();
  assert.strictEqual(data.user.role, 'admin', 'Configured owner email must be provisioned as admin');
});

test('API - Assessment submission, score sum to 15, and privacy protection', async () => {
  // Register student
  const studentEmail = `student_${Date.now()}@fpt.edu.vn`;
  const regRes = await fetch(`${baseUrl}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: studentEmail,
      password: 'password123',
      fullName: 'Đỗ Thị Lan'
    })
  });
  const regData = await regRes.json();
  const token = regData.token;
  const studentId = regData.user.id;

  // Submit all 15 answers
  const answers = {};
  for (let i = 1; i <= 15; i++) {
    // Pick option A, B, C, D, or E
    answers[i] = ['A', 'B', 'C', 'D', 'E'][(i - 1) % 5];
  }

  const submitRes = await fetch(`${baseUrl}/api/assessment/submit`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ answers })
  });

  assert.strictEqual(submitRes.status, 201);
  const result = await submitRes.json();
  assert.strictEqual(result.totalScore, 15, 'Total assessment score must strictly sum to 15');
  assert.ok(result.primaryStrength);
  assert.ok(result.secondaryStrength);

  // Update privacy: hide email and phone, publish profile
  await fetch(`${baseUrl}/api/profile/privacy`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
      isPublished: true,
      directoryVisible: true,
      showStrengths: true,
      showEmail: false,
      showPhone: false
    })
  });

  // Another peer student looks at Lan's profile
  const peerEmail = `peer_${Date.now()}@gmail.com`;
  const peerReg = await fetch(`${baseUrl}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: peerEmail,
      password: 'password123',
      fullName: 'Bạn Học Khác'
    })
  });
  const peerData = await peerReg.json();

  const peerViewRes = await fetch(`${baseUrl}/api/profile/${studentId}`, {
    headers: { 'Authorization': `Bearer ${peerData.token}` }
  });

  assert.strictEqual(peerViewRes.status, 200);
  const peerViewData = await peerViewRes.json();

  // Strict privacy assertions:
  assert.strictEqual(peerViewData.email, undefined, 'Peer cannot see private email');
  assert.strictEqual(peerViewData.phone, undefined, 'Peer cannot see private phone');
  assert.ok(peerViewData.assessment);
  assert.strictEqual(peerViewData.assessment.answers, undefined, 'Peer CANNOT see individual 15 answers');
});

test('API - Non-admin cannot access admin endpoints', async () => {
  const studentEmail = `regular_${Date.now()}@gmail.com`;
  const regRes = await fetch(`${baseUrl}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: studentEmail,
      password: 'password123',
      fullName: 'Học Viên Bình Thường'
    })
  });
  const regData = await regRes.json();

  // Try accessing admin metrics
  const metricRes = await fetch(`${baseUrl}/api/admin/metrics`, {
    headers: { 'Authorization': `Bearer ${regData.token}` }
  });
  assert.strictEqual(metricRes.status, 403);

  // Try generating teams
  const groupRes = await fetch(`${baseUrl}/api/admin/teams/generate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${regData.token}`
    },
    body: JSON.stringify({ teamCount: 6 })
  });
  assert.strictEqual(groupRes.status, 403);
});

test('API - Admin can delete assessment results and delete student accounts', async () => {
  // Login as admin
  const adminLoginRes = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: config.adminEmail,
      password: 'adminPassword123'
    })
  });
  const adminLogin = await adminLoginRes.json();
  const adminToken = adminLogin.token;

  // Create a student to test deletion
  const testStudentEmail = `delete_me_${Date.now()}@gmail.com`;
  const studentRegRes = await fetch(`${baseUrl}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: testStudentEmail,
      password: 'studentPassword123',
      fullName: 'Sinh Viên Chuẩn Bị Xóa'
    })
  });
  const studentData = await studentRegRes.json();
  const studentUserId = studentData.user.id;

  // Submit test for this student
  const answers = {};
  for (let i = 1; i <= 15; i++) answers[i] = 'A';
  await fetch(`${baseUrl}/api/assessment/submit`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${studentData.token}`
    },
    body: JSON.stringify({ answers })
  });

  // Verify assessment exists in DB
  const assessBefore = db.prepare('SELECT id FROM assessments WHERE user_id = ?').get(studentUserId);
  assert.ok(assessBefore);

  // 1. Admin deletes assessment
  const deleteAssessRes = await fetch(`${baseUrl}/api/admin/users/${studentUserId}/assessment`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert.strictEqual(deleteAssessRes.status, 200);

  // Verify assessment is removed
  const assessAfter = db.prepare('SELECT id FROM assessments WHERE user_id = ?').get(studentUserId);
  assert.strictEqual(assessAfter, undefined, 'Assessment must be deleted');

  // 2. Admin deletes registered student account
  const deleteUserRes = await fetch(`${baseUrl}/api/admin/users/${studentUserId}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert.strictEqual(deleteUserRes.status, 200);

  // Verify user is removed completely
  const userAfter = db.prepare('SELECT id FROM users WHERE id = ?').get(studentUserId);
  assert.strictEqual(userAfter, undefined, 'User account must be deleted completely');
});

test('API - Admin content moderation workflow (Pending, Approve, Reject)', async () => {
  // Login as admin
  const adminLoginRes = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: config.adminEmail,
      password: 'adminPassword123'
    })
  });
  const adminLogin = await adminLoginRes.json();
  const adminToken = adminLogin.token;

  // Register student
  const studentEmail = `mod_student_${Date.now()}@fpt.edu.vn`;
  const regRes = await fetch(`${baseUrl}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: studentEmail,
      password: 'password123',
      fullName: 'Student Poster'
    })
  });
  const studentData = await regRes.json();

  // Student creates a community post
  const postRes = await fetch(`${baseUrl}/api/community/posts`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${studentData.token}`
    },
    body: JSON.stringify({
      title: 'Đề tài cần tuyển Teammate Research',
      content: 'Cần tìm bạn kiểm chứng dữ liệu cho dự án AI',
      lookingForStrengths: ['Research']
    })
  });
  assert.strictEqual(postRes.status, 201);
  const postData = await postRes.json();
  assert.strictEqual(postData.status, 'pending', 'Student post must be pending by default');

  // Admin checks pending posts
  const pendingPostsRes = await fetch(`${baseUrl}/api/admin/posts?status=pending`, {
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert.strictEqual(pendingPostsRes.status, 200);
  const pendingData = await pendingPostsRes.json();
  assert.ok(pendingData.pendingCount >= 1);
  const foundPending = pendingData.posts.find(p => p.id === postData.id);
  assert.ok(foundPending);
  assert.strictEqual(foundPending.status, 'pending');

  // Admin approves the post
  const approveRes = await fetch(`${baseUrl}/api/admin/posts/${postData.id}/status`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${adminToken}`
    },
    body: JSON.stringify({ status: 'approved' })
  });
  assert.strictEqual(approveRes.status, 200);

  // Verify post is now approved and visible in public community feed
  const feedRes = await fetch(`${baseUrl}/api/community/posts`);
  const feedData = await feedRes.json();
  const approvedPostInFeed = feedData.posts.find(p => p.id === postData.id);
  assert.ok(approvedPostInFeed);
  assert.strictEqual(approvedPostInFeed.status, 'approved');
});

test('API - Admin can confirm, delete single team, and delete all confirmed teams', async () => {
  // Login as admin
  const adminLoginRes = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: config.adminEmail,
      password: 'adminPassword123'
    })
  });
  const adminLogin = await adminLoginRes.json();
  const adminToken = adminLogin.token;

  // 1. Save dummy confirmed teams
  const dummyTeams = [
    {
      teamNumber: 1,
      teamName: 'Nhóm 1 - Test Group',
      diversityScore: 5,
      missingPrimaryStrengths: [],
      repeatedPrimaryStrengths: [],
      members: []
    },
    {
      teamNumber: 2,
      teamName: 'Nhóm 2 - Test Group',
      diversityScore: 4,
      missingPrimaryStrengths: ['Research'],
      repeatedPrimaryStrengths: ['Communication'],
      members: []
    }
  ];

  const confirmRes = await fetch(`${baseUrl}/api/admin/teams/confirm`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${adminToken}`
    },
    body: JSON.stringify({ teams: dummyTeams })
  });
  assert.strictEqual(confirmRes.status, 200);

  // 2. Fetch confirmed teams
  const getRes = await fetch(`${baseUrl}/api/admin/teams/confirmed`, {
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert.strictEqual(getRes.status, 200);
  const getData = await getRes.json();
  assert.strictEqual(getData.totalTeams, 2);

  const team1 = getData.teams[0];
  const team2 = getData.teams[1];

  // 3. Delete single team
  const deleteSingleRes = await fetch(`${baseUrl}/api/admin/teams/confirmed/${team1.id}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert.strictEqual(deleteSingleRes.status, 200);

  // Verify only 1 team left
  const getAfterSingleRes = await fetch(`${baseUrl}/api/admin/teams/confirmed`, {
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  const afterSingleData = await getAfterSingleRes.json();
  assert.strictEqual(afterSingleData.totalTeams, 1);
  assert.strictEqual(afterSingleData.teams[0].id, team2.id);

  // 4. Delete all remaining teams
  const deleteAllRes = await fetch(`${baseUrl}/api/admin/teams/confirmed`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert.strictEqual(deleteAllRes.status, 200);

  // Verify 0 teams left
  const getAfterAllRes = await fetch(`${baseUrl}/api/admin/teams/confirmed`, {
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  const afterAllData = await getAfterAllRes.json();
  assert.strictEqual(afterAllData.totalTeams, 0);
});
